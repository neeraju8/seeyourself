module.exports = async (req, res) => {
  if (process.env.ACCESS_CODE && req.headers['x-access-code'] !== process.env.ACCESS_CODE)
    return res.status(401).json({ error: 'Wrong access code.' });
  const id = String(req.query.id || '');
  if (!/^[a-z0-9]+$/i.test(id)) return res.status(400).json({ error: 'Bad id.' });
  try {
    const p = await fetch(`https://api.replicate.com/v1/predictions/${id}`, {
      headers: { Authorization: `Bearer ${process.env.REPLICATE_API_TOKEN}` }
    }).then(r => r.json());
    const out = Array.isArray(p.output) ? p.output[0] : p.output;
    res.status(200).json({ status: p.status, output: out || null, error: p.error || null });
  } catch (e) { res.status(500).json({ error: 'Server error. Try again.' }); }
};
