const MODEL = 'ddvinh1/tool-faceswap-video';
const CLIPS = ['clip1', 'clip2', 'clip3'];

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST' });
  if (process.env.ACCESS_CODE && req.headers['x-access-code'] !== process.env.ACCESS_CODE)
    return res.status(401).json({ error: 'Wrong access code.' });
  const { selfie, clipId } = req.body || {};
  if (!String(selfie).startsWith('data:image/') || !CLIPS.includes(clipId))
    return res.status(400).json({ error: 'Add a selfie and pick a reel.' });
  const H = { Authorization: `Bearer ${process.env.REPLICATE_API_TOKEN}`, 'Content-Type': 'application/json' };
  try {
    const m = await fetch(`https://api.replicate.com/v1/models/${MODEL}`, { headers: H }).then(r => r.json());
    const version = m.latest_version && m.latest_version.id;
    if (!version) return res.status(502).json({ error: 'Swap model not found. Check MODEL in api/swap.js.' });
    const r = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST', headers: H,
      body: JSON.stringify({ version, input: { source_image: selfie, target_video: `https://${req.headers.host}/clips/${clipId}.mp4`, mode: 'single' } })
    });
    const p = await r.json();
    if (!r.ok) return res.status(502).json({ error: p.detail || 'Could not start the swap.' });
    res.status(200).json({ id: p.id });
  } catch (e) { res.status(500).json({ error: 'Server error. Try again.' }); }
};
