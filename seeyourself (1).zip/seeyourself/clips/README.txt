Put 3 short MP4 clips here named clip1.mp4, clip2.mp4, clip3.mp4 (clips you own or licensed).
